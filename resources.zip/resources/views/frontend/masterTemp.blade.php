@include('frontend.include.header')

<div class="">
    @include('frontend.include.menu')

    @yield('front-main-content')

    @include('frontend.include.footer')
    @include('frontend.include.footer_links')
