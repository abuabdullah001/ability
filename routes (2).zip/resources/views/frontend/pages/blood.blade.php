@extends('frontend.masterTemp')
@section('fmenuname')
Blood Donation camp
@endsection
@section('front-main-content')

<div class="clearfix"></div>

<!-- Title Header Start -->
<section class="inner-header-title" style="background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTPAh3KL6KrfJXJrc1glaYJYArcrQ2Wxp_07w&usqp=CAU);">
    <div class="container">
    <h1>Blood Donation camp</h1>
        <p >BIEA পরিবারের কোন সদস্যের রক্তের প্রয়োজন হলে অগ্রাধিকার ভিত্তিতে রক্তের ব্যবস্থা করে দিতে ২৪/৭ প্রস্তুত থাকবে ব্লাড ডোনেশন ক্যাম্প।  <br>
          শুভেচ্ছান্তে,
BIEA Blood Authority.</p>
    </div>
</section>

<br>
<br>
<br>
<br>
<br>
<br>
<br>

@endsection