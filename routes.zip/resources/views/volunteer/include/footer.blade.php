 <footer class="main-footer" id="printPageButton">
                <strong>Copyright &copy; 2023 <a target="_blank" href="">All Rights Reserved AFDF - 2024</a>.</strong>
                All rights reserved.
                <div class="float-right d-none d-sm-inline-block">
                    <a target="_blank" href="https://itwaybd.com/">Developed By <strong style="color: red">IT WAY BD</strong> </a><b>|| Version</b> 1.1 pro
                </div>
            </footer>
